// imports

const constantDemo = {
  constantOne: "StringType",
  constantTwo: 123,
  ConstantThree: (parameter) => {
    //function-like constant
    return parameter;
  },
};

export { constantDemo };
