from django.db import models
from django.conf import settings
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.utils.translation import gettext as _
from django.contrib.contenttypes.fields import GenericRelation
from django.core.validators import MinValueValidator
from django.contrib.auth.models import AbstractUser, Group
 

class locations_country(models.Model):
    pk_idcountry = models.AutoField(db_column='PK_IdCountry', primary_key=True)  # Field name made lowercase.
    name = models.CharField(max_length=50)
    iso = models.CharField(max_length=3)
    continent = models.CharField(max_length=30, choices = CONTINENT, default='south_america')                        
    coordinates = models.CharField(max_length=50, null=True)
    class Meta:
        db_table = 'locations_country'
        verbose_name_plural = "Countries"
    def __str__(self):
        return self.name 

class locations_city(models.Model):
    pk_idcity = models.AutoField(db_column='PK_IdCity', primary_key=True)  # Field name made lowercase.
    fk_country= models.ForeignKey(locations_country, on_delete= models.CASCADE, db_column='FK_IdCountry')
    name = models.CharField(max_length=50)                                    
    coordinates = models.CharField(max_length=50, null=True)
    class Meta:
        db_table = 'locations_city'
        verbose_name_plural = "Cities"
    def __str__(self):
        return self.name

class datasources_datasource(models.Model):
    pk_iddatasource = models.AutoField(db_column='PK_IdDataSource', primary_key=True)
    datasource_name = models.CharField(max_length=50)
    datasource_link = models.CharField(max_length=500)
    datasource_username = models.CharField(max_length=50, blank=True, null=True)
    datasource_password = models.CharField(max_length=50, blank=True, null=True)
    datasource_status = models.CharField(max_length=30, choices = STATUS, default='active')
    datasource_type = models.CharField(max_length=30, choices = STATUS, default='api')
    token_source = models.CharField(max_length=200, blank=True, null=True)
    created = models.DateTimeField(auto_now_add=True)
    class Meta:
        db_table = 'datasources_datasource'
        verbose_name_plural = "Datasources"
    def __str__(self):
        return '{}'.format(self.data_source_name)

class sell(models.Model):
    pk_idsell = models.AutoField(db_column='pk_idsell', primary_key=True)
    datasource_name = models.CharField(max_length=50)
    datasource_link = models.CharField(max_length=500)
    datasource_username = models.CharField(max_length=50, blank=True, null=True)
    datasource_password = models.CharField(max_length=50, blank=True, null=True)
    datasource_status = models.CharField(max_length=30, choices = STATUS, default='active')
    datasource_type = models.CharField(max_length=30, choices = STATUS, default='api')
    token_source = models.CharField(max_length=200, blank=True, null=True)
    created = models.DateTimeField(auto_now_add=True)
    class Meta:
        db_table = 'datasources_datasource'
        verbose_name_plural = "Datasources"
    def __str__(self):
        return '{}'.format(self.data_source_name)


class axie(models.Model):
    pk_idaxie= models.AutoField(db_column='pk_idaxie', primary_key=True)  # Field name made lowercase.
    health = models.CharField(max_length=1000, default=None, null=True)
    speed = models.CharField(max_length=1000, default=None, null=True)
    skill = models.CharField(max_length=1000, default=None, null=True)
    morale = models.CharField(max_length=1000, default=None, null=True)
    bodyparts = models.CharField(max_length=1000, default=None, null=True)
    parents = models.ForeignKey(axie, on_delete= models.CASCADE, db_column='fk_idaxie', related_name='Axie')

    class Meta:
        db_table = 'axie'
        verbose_name_plural = "axies"

    def __str__(self):
        return self.name

        
class genetic(models.Model):
    pk_idgenetic = models.AutoField(db_column='pk_idgenetic', primary_key=True)  # Field name made lowercase.
    name = models.CharField(max_length=100, default=None)
    fk_idaxie= models.ForeignKey(axie, on_delete= models.CASCADE, db_column='fk_idaxie', related_name='Axie')
    capacity = models.CharField(max_length=30,default=None)
    stats = models.FloatField(default=None, null=True)
    consumption = models.FloatField(default=None, null=True)
    extras = models.CharField(max_length=10000, default=None, null=True)

    class Meta:
        db_table = 'genetic'
        verbose_name_plural = "genetic"

class Letters(models.Model):
    pk_idletter = models.AutoField(db_column='pk_idletter', primary_key=True)  # Field name made lowercase.
    fk_idaxie= models.ForeignKey(axie, on_delete= models.CASCADE, db_column='fk_idaxie', related_name="axie")                                                            
    year = models.IntegerField(default=None)
    price = models.IntegerField(default=None)
    code = models.CharField(max_length=200)
    description = models.CharField(max_length=1000, default=None, null=True)
    version = models.CharField(max_length=50, default=None)
    extras = models.CharField(max_length=10000, default=None, null=True)
    extra_location = models.CharField(max_length=10000, default=None, null=True)
    post_url = models.CharField(max_length=10000, default=None, null=True)
    url_imgs = models.CharField(max_length=10000, default=None, null=True)
    status = models.CharField(max_length=30, choices = STATUS, default='active')
    created = models.DateTimeField(auto_now_add=True, editable=False)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'breeding'
        verbose_name_plural = "Breeding"


class Letter(models.Model):
    pk_idletter= models.AutoField(db_column='pk_idletter', primary_key=True)  # Field name made lowercase.
    fk_axie= models.ForeignKey(axie, on_delete= models.CASCADE, db_column='fk_axie', related_name="axie")
    price_value = models.FloatField(default=None)
    created = models.DateTimeField(auto_now_add=True, editable=False)

    class Meta:
        db_table = 'letter'
        verbose_name_plural = "Letters"


    def __str__(self):
        return self.pk_idletter

class Abilitie(models.Model):
    pk_idabilitie = models.AutoField(db_column='pk_idabilitie', primary_key=True)
    fk_axie= models.ForeignKey(axie, on_delete= models.CASCADE, db_column='fk_idaxie')
    image = models.CharField(max_length=10000, default=None, null=True)
    description = models.DateTimeField(auto_now_add=True, editable=False)
    stats = models.FloatField(default=None, null=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'Abilitie'
        verbose_name_plural = "Abilities"

    def __str__(self):
        return self.pk_idabilitie


