
#!/usr/bin/env python3

import pandas as pd
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.options import Options
from os import listdir
import ast
import datetime
from joblib import Parallel, delayed
import multiprocessing
import threading
import time
import re
import os
import numpy as np
import pickle
import unidecode
import math
from main.models import vehicles_brand, vehicles_vehicle, vehicles_model, datasources_datasource, locations_city, locations_country

class TuCarro():
    
    def __init__(self):
        #options = Options()
        #options.headless = True
        #driver = webdriver.Chrome('/home/inkremental/Documentos/Carru/extraction_ms/files/drivers/chromedriver',options=options)
        #self.wait = WebDriverWait(driver, 15)
        #self.driver.get('https://carros.tucarro.com.co/_ITEM*CONDITION_2230581_all*payment*methods*discount_cash*discount')
        self.list_urls = []
        self.rows_list = []
        self.process_tucarro()

    def process_tucarro(self):
        now = datetime.datetime.now()
        current_year = int(now.year)
        years = []
        # for i in range(1990,1991):
        #     lst = self.retrieve_urls(i)
        #     for n in lst:
        #         self.list_urls.append(n) 

        # total_vehicles = len(self.list_urls)
        start = time.time()

        n_jobs = multiprocessing.cpu_count()
        
        lst1 = [2001,2003]
        lst2 = [2003,2007]
        # lst11 = [2015, 2018]
        # lst12 = [2018, 2022]

        t1 = threading.Thread(target=self.retrieve_urls, args=(lst1,)) 
        t2 = threading.Thread(target=self.retrieve_urls, args=(lst2,)) 
        # t3 = threading.Thread(target=self.retrieve_urls, args=(lst3,)) 
        # t4 = threading.Thread(target=self.retrieve_urls, args=(lst4,)) 
        # t11 = threading.Thread(target=self.retrieve_urls, args=(lst11,)) 
        # t12 = threading.Thread(target=self.retrieve_urls, args=(lst12,))

        t1.start() 
        t2.start()         
        # t3.start()         
        # t4.start()
        # t11.start()
        # t12.start()

        t1.join()                 
        t2.join()         
        # t3.join()         
        # t4.join()
        # t11.join()
        # t12.join()

        end = time.time()

        print('primary time: ', end-start)
        total_cars = len(self.list_urls)
        print('total cars: ', total_cars)


        lst5 = []
        lst6 = []
        lst7 = []
        lst8 = []
        # lst9 = []
        # lst10 = []

        f = 0

        amount = round(total_cars/4)

        for f in range(0,4):
            q = amount * f
            w = amount*(f+1)
            for g in range(q,w):
                if f == 0:
                    lst5.append(self.list_urls[g])
                if f == 1:
                    lst6.append(self.list_urls[g])
                if f == 2:
                    lst7.append(self.list_urls[g])
                if f == 3:
                    try:
                        lst8.append(self.list_urls[g])
                    except:
                        print('Even length of chunk')

        start = time.time()



        t5 = threading.Thread(target=self.retrieve_vehicle, args=(lst5,)) 
        t6 = threading.Thread(target=self.retrieve_vehicle, args=(lst6,)) 
        t7 = threading.Thread(target=self.retrieve_vehicle, args=(lst7,)) 
        t8 = threading.Thread(target=self.retrieve_vehicle, args=(lst8,)) 
        # t9 = threading.Thread(target=self.retrieve_vehicle, args=(lst9,)) 
        # t10 = threading.Thread(target=self.retrieve_vehicle, args=(lst10,)) 

        t5.start() 
        t6.start()         
        t7.start()         
        t8.start()
        # t9.start()
        # t10.start()

        t5.join()                 
        t6.join()         
        t7.join()         
        t8.join()
        # t9.join()
        # t10.join()

        end = time.time()
        print('secondary time: ', end-start)

        print('cars added:' , len(self.rows_list))


        path_csvs = "/home/inkremental/Documentos/Carru/extraction_ms/files/"
        #driver = webdriver.Chrome('/home/ivan/extraction_ms/files/drivers/chromedriver',options=options)
        files = listdir(path_csvs)    
        files = [x for x in files if x.endswith('.csv')]
        df_total = pd.DataFrame()
        for i,file in enumerate(files):
            csv = pd.read_csv(path_csvs + files[i])
            csv.drop_duplicates(subset=['Año', 'Kilómetros'], inplace=True, keep='first')
            df_total = df_total.append(csv)

        #df_total.to_csv("data_tu_carro_co_complete.csv", index = False)
        self.clean_tucarro(df_total)

    def retrieve_urls(self, data):
        urls_vehicles = []
        options = Options()
        options.headless = True
        #driver = webdriver.Chrome('/home/ivan/extraction_ms/files/drivers/chromedriver',options=options)
        driver = webdriver.Chrome('/home/inkremental/Documentos/Carru/extraction_ms/files/drivers/chromedriver',options=options)
        wait = WebDriverWait(driver, 15)
        year = data[0]
        for year in range(data[0],data[1]):
            current_page = 1
                #print('entered ', year)
            for j in range(1,43):
                #print(j)
                if current_page == 1: 
                    url_page = 'https://carros.tucarro.com.co/' + str(year) + '/_ITEM*CONDITION_2230581_all*payment*methods*discount_cash*discount'
                    print('current page: ' + str(current_page) + ', current_year: ' + str(year))
                    current_page +=  48
                else:
                    url_page = 'https://carros.tucarro.com.co/' + str(year) + '/_Desde_' + str(current_page) +'_ITEM*CONDITION_2230581_all*payment*methods*discount_cash*discount'
                    current_page +=  48
                    print('current page: ' + str(current_page) + ', current_year: ' + str(year))
                driver.get(url_page)
                try:
                    #print('try ', year, ' ' , current_page)
                    ol_search_results = driver.find_element_by_id('searchResults')
                except Exception as e:
                    #print('exiting ', year)
                    break
                articles_list = ol_search_results.find_elements_by_xpath('./li[@class="results-item highlighted article grid "]')
                for article in articles_list:  
                    link_article_a = article.find_element_by_tag_name('a')
                    url_articles = link_article_a.get_attribute('href')
                    self.list_urls.append(url_articles)
        #print(urls_vehicles)
        driver.quit()
        return urls_vehicles


    def retrieve_vehicle(self, data):
        dict_datos = {}
        options = Options()
        options.headless = True
        #driver = webdriver.Chrome('/home/ivan/extraction_ms/files/drivers/chromedriver',options=options)        
        driver = webdriver.Chrome('/home/inkremental/Documentos/Carru/extraction_ms/files/drivers/chromedriver',options=options)        
        wait = WebDriverWait(driver, 15)
        #for k in range(len(list_urls_access)):
        for w in data:
            driver.get(w)
                #imágenes
            try:
                wait.until(EC.presence_of_element_located((By.CLASS_NAME, 'gallery-content.item-gallery__wrapper')))
                gallery = driver.find_element_by_class_name('gallery-content.item-gallery__wrapper')
                list_imagenes_str = gallery.get_attribute('data-full-images')
                list_imagenes = ast.literal_eval(list_imagenes_str)
                imagenes_articulo = []
                for dict_images in list_imagenes:
                    imagenes_articulo.append(list_imagenes)
                dict_datos['url_imagenes'] = imagenes_articulo
            except Exception as e:
                print(e)
                dict_datos['url_imagenes'] = 'NA'    
                #lista_artículos
            try:
                wait.until(EC.presence_of_element_located((By.CLASS_NAME, 'specs-list')))
                unordered_list_datos = driver.find_element_by_class_name('specs-list')
                listas_datos = unordered_list_datos.find_elements_by_tag_name('li')
                for elemento in listas_datos:
                    elemento_strong = elemento.find_element_by_tag_name('strong').text
                    elemento_span = elemento.find_element_by_tag_name('span').text
                    dict_datos[elemento_strong] = elemento_span
            except Exception as e:
                print(e)
            #price
            try:
                wait.until(EC.presence_of_element_located((By.CLASS_NAME, 'specs-list')))
                elemento_precio = driver.find_element_by_class_name('price-tag.price-tag-motors')
                precio = elemento_precio.find_element_by_class_name('price-tag-fraction').text
                dict_datos['precio'] = precio
            except Exception as e:
                print(e)
                dict_datos['precio'] = 'NA'
                #marca
            try:
                wait.until(EC.presence_of_element_located((By.CLASS_NAME, 'specs-list')))
                elemento_marca = driver.find_element_by_class_name('vip-navigation-breadcrumb-list')
                marca = elemento_marca.find_elements_by_xpath ('//*[@id="root-app"]/div/section[1]/nav/div/ul/li[3]/a')[0].text
                dict_datos['marca'] = marca
            except Exception as e:
                print(e)
                dict_datos['marca'] = 'NA'
            #modelo
            try:
                wait.until(EC.presence_of_element_located((By.CLASS_NAME, 'specs-list')))
                elemento_modelo = driver.find_element_by_class_name('vip-navigation-breadcrumb-list')
                modelo = elemento_modelo.find_elements_by_xpath('//*[@id="root-app"]/div/section[1]/nav/div/ul/li[4]/a')[0].text
                dict_datos['modelo'] = modelo
            except Exception as e:
                print(e)
                dict_datos['modelo'] = 'NA'
            #ubicación
            try:
                wait.until(EC.presence_of_element_located((By.CLASS_NAME, 'location-info')))
                elemento_ubicacion = driver.find_element_by_class_name('ui-icon--content')
                ubicacion = elemento_ubicacion.find_elements_by_xpath('//*[@id="root-app"]/div/div/div[1]/div[2]/div[1]/section[3]/div[2]/span')[0].text
                dict_datos['ubicacion'] = ubicacion
            except Exception as e:
                print(e)
                dict_datos['ubicacion'] = 'NA'
            code = w.replace('https://articulo.tucarro.com.co/', '')
            #print('code', code)
            dict_datos['code'] = code
            #print(dict_datos)
            try:
                df_articulo = pd.DataFrame(dict_datos)
                #df_articulo.to_csv('/home/ivan/files/' + code + '.csv')
                df_articulo.to_csv('/home/inkremental/Documentos/Carru/extraction_ms/files/files/' + code + '.csv')
                self.rows_list.append(dict_datos)
                print('Vehicles added: ' , len(self.rows_list))
            except Exception as e:
                print(e)
                print('Error saving vehicle: ', code)
        driver.quit()

    def try_chance(self, car_make, chance, badmake2goodmake, ii):
        found = False
        for poss in set(badmake2goodmake.values()):
            if chance in poss:
                clean = chance
                found = True
                return clean
        if not found:
            return None

    def clean_kilómetros_tucarro(self, x):
        if pd.isna(x):
            return np.nan
        x = x.replace('.','')
        x = x.replace(' ','')
        x = x.replace('km','')
        return int(x)

    def cc_cleaner(self, p):
        try:
            cc = float(p)
        except ValueError:
            cc = p
            
        try:
            if math.floor(math.log(cc, 10))==4:
                cc = cc*0.1
            elif math.floor(math.log(cc, 10))==3:
                cc = cc
            elif math.floor(math.log(cc, 10))==2:
                if cc < 500:
                    cc = cc*10
                else:
                    cc = cc
            elif math.floor(math.log(cc, 10))==1:
                cc = cc*100
            elif math.floor(math.log(cc, 10))==0:
                cc = cc*1000
            ret = True
        except Exception as e:
            print(e)
            cc = p
            ret = False
        return cc, ret

    def clean_tucarro(self, for_sale):
        consum = pd.read_csv('/home/inkremental/Documentos/Carru/extraction_ms/files/data_in/vehicles_consumption.csv')
        consum['make'] = consum.make.str.lower()
        consum['model'] = consum.model.str.lower()
        consum['city08'] = consum.city08*1.6093439985275
        consum['comb08'] = consum.comb08*1.6093439985275
        consum['displ'] = consum.displ.fillna(0).astype(int)*1000
        consum = consum[['make', 'model', 'displ', 'city08', 'comb08', 'year']]

        with open('/home/inkremental/Documentos/Carru/extraction_ms/files/data_in/make_error_dict.pickle', 'rb') as handle:
            badmake2goodmake = pickle.load(handle)

        with open('/home/inkremental/Documentos/Carru/extraction_ms/files/data_in/cc_error_dict.pickle', 'rb') as handle:
            badcc2goodcc = pickle.load(handle)      

        for_sale = for_sale.fillna({'marca':''})
        print('1', for_sale.shape)

        make_list = []
        for marca in for_sale.marca:
            try:
                make = badmake2goodmake[marca]
            except KeyError:
                make = ''
            make_list.append(make)
        for_sale['make'] = make_list

        makes = []
        for ii, car_make in enumerate(list(for_sale.make)):
            if car_make in ['']:
                chance = list(for_sale.code)[ii].split('-')[2]
                
                # case 1.1
                if chance in set(badmake2goodmake.values()):
                    makes.append(chance)
                    continue
                
                # case 1.2    
                if chance in badmake2goodmake.keys():
                    makes.append(badmake2goodmake[chance])
                    continue
                
                # case 2
                clean = self.try_chance(car_make, chance, badmake2goodmake, ii)
                if clean:
                    makes.append(chance)
                    continue
                    
                # case 3
                makes.append('')
            else:
                makes.append(car_make)
        for_sale['make'] = makes

        for_sale['p_code'] = for_sale.code.apply(lambda x: x.split('-')[1])

        for_sale = for_sale.drop(for_sale[for_sale.make==''].index)
        print('2', for_sale.shape)

        for_sale = for_sale.dropna(subset=['modelo'])
        print('3', for_sale.shape)
        for_sale['model'] = for_sale.modelo.apply(lambda x: unidecode.unidecode(x.lower()))
        for_sale['kilometraje'] = for_sale.Kilómetros.apply(self.clean_kilómetros_tucarro)
        for_sale['year'] = for_sale.Año

        for_sale = for_sale.dropna(subset=['Motor'])
        print('4', for_sale.shape)

        cc_list = []
        for Motor in for_sale.Motor:
            cc, ret = self.cc_cleaner(Motor)
            if not ret:
                try:
                    cc = badcc2goodcc[Motor]
                except KeyError:
                    cc = np.nan
            cc_list.append(cc)
        for_sale['CC'] = cc_list

        for_sale = for_sale.dropna(subset=['CC'])
        print('5', for_sale.shape)

        for_sale['Tipo de combustible'] = for_sale['Tipo de combustible'].apply(lambda x: unidecode.unidecode(x.lower()))

        for_sale['make_model_year_cc_tc'] = for_sale.make+'_'+for_sale.model+'_'+for_sale.year.astype(str)+'_'+for_sale.CC.astype(str)+'_'+for_sale['Tipo de combustible']

        models = for_sale.dropna(subset=['CC'])
        print('1 models', models.shape)
        models = models.drop_duplicates(subset=['make_model_year_cc_tc'])[['make_model_year_cc_tc']]
        models[['make', 'model', 'year', 'CC', 'tc']] = models['make_model_year_cc_tc'].str.split('_', 4, expand=True)
        models = models[['make','model','year', 'CC', 'tc', 'make_model_year_cc_tc']]
        models['year'] = models.year.astype(int)
        models['CC'] = models.CC.astype(float)

        models_old = pd.read_csv('/home/inkremental/Documentos/Carru/extraction_ms/files/data_in/models_consum.csv')
        consumos_ciudad = []
        consumos_mixto = []
        m = 0
        for index, row in models.iterrows():
            if row.make_model_year_cc_tc in models_old.make_model_year_cc_tc:
                continue
            
            #print()
            #print('---', index, row.make, row.model, row.year, row.CC, row.tc, '---')    
            
            consum_marca = consum[consum.make==row.make]
            
            if (consum_marca.shape[0]==0):
                #print('    NO DATA FOR MAKE')
                consumos_ciudad.append(np.nan)
                consumos_mixto.append(np.nan)
                continue
            
            #print('    direct search:')
            selector_model = []
            for ii, consum_row in consum_marca.iterrows():
                select_model = False
                if consum_row.model == row.model:
                    select_model = True
                selector_model.append(select_model)
            consum_modelo = consum_marca[(selector_model)]
            
            if consum_modelo.shape[0]==0:
                #print('        model search:')
                selector_model = []
                for ii, consum_row in consum_marca.iterrows():
                    select_model = False
                    if row.model in consum_row.model:
                        select_model = True
                    selector_model.append(select_model)
                consum_modelo = consum_marca[(selector_model)]
            else:
                None
                #print('    no model search')
                
            if consum_modelo.shape[0]==0:
                #print('            word search:')
                selector_model = []
                for ii, consum_row in consum_marca.iterrows():
                    select_model = False        
                    for word in row.model.split():
                        if word in consum_row.model.split():
                            select_model = True
                            break   
                    selector_model.append(select_model)
                consum_modelo = consum_marca[(selector_model)]
            else:
                #print('        no word search')
                None
                
            if consum_modelo.shape[0]==0:
                #print('            NO DATA FOR MODEL')
                consumos_ciudad.append(np.nan)
                consumos_mixto.append(np.nan)
                continue

            if consum_modelo.shape[0]>0:
                if consum_modelo[(abs(consum_modelo.displ-row.CC)<=500)].shape[0]>0:
                    #print('    motor capacity selected')
                    consum_modelo = consum_modelo[(abs(consum_modelo.displ-row.CC)<=500)]
                else:
                    #print('    NO DATA FOR MOTOR CAPACITY')
                    consumos_ciudad.append(np.nan)
                    consumos_mixto.append(np.nan)
                    continue

            if consum_modelo.shape[0]>0:
                if consum_modelo[consum_modelo.year==row.year].shape[0]>0:
                    #print('    exact year selected')
                    consum_modelo = consum_modelo[consum_modelo.year==row.year]
                else:
                    #print('    no exact year')
                    consum_modelo = consum_modelo[abs(consum_modelo.year-row.year)<=4]
            
            if consum_modelo.shape[0]==0:
                #print('    NO DATA WITHIN 8 YEARS')
                consumos_ciudad.append(np.nan)
                consumos_mixto.append(np.nan)
                continue
            
            if row.tc in ['diesel', 'gasolina', 'gasolina y gas']:
                consum_modelo = consum_modelo[(consum_modelo.displ!=0)]
            if row.tc=='electrico':
                consum_modelo = consum_modelo[(consum_modelo.displ==0)]
            if row.tc=='hibrido':
                consum_modelo = consum_modelo[(consum_modelo.displ=='santiago')]
            
            if consum_modelo.shape[0]>0:
                consumo_ciudad = consum_modelo.city08.mean()
                consumo_mixto = consum_modelo.comb08.mean()
            else:
                consumo_ciudad = np.nan
                consumo_mixto = np.nan
                
            #print(consum_modelo)
            
            consumos_ciudad.append(consumo_ciudad)
            consumos_mixto.append(consumo_mixto)
        models['consumos_ciudad'] = consumos_ciudad
        models['consumos_mixto'] = consumos_mixto
        models = pd.concat([models_old, models])
        models.to_csv('/home/inkremental/Documentos/Carru/extraction_ms/files/data_in/models_consum.csv')

        consumos_ciudad_fs = []
        consumos_mixtos_fs = []
        for ii, fs in for_sale.iterrows():    
            if models[(models.make==fs.make)&(models.model==fs.model)&(models.year==fs.year)&(models.CC==fs.CC)].shape[0]>0:
                co_c = models[
                    (models.make==fs.make)&(models.model==fs.model)&(models.year==fs.year)&(models.CC==fs.CC)
                ].consumos_ciudad.mean()
                co_m = models[
                    (models.make==fs.make)&(models.model==fs.model)&(models.year==fs.year)&(models.CC==fs.CC)
                ].consumos_mixto.mean()
            else:
                co_c = np.nan
                co_m = np.nan
            consumos_ciudad_fs.append(co_c)
            consumos_mixtos_fs.append(co_m)
        for_sale['city_consum'] = consumos_ciudad_fs
        for_sale['mixed_consum'] = consumos_mixtos_fs

        self.create_vehicles(for_sale)

    def create_vehicles(self, for_sale):
        principal_df = for_sale.copy(deep=True)
        principal_df['precio'] = principal_df.precio.apply(lambda x: x.replace('.',''))
        i = 0
        for index, row in principal_df.iterrows():
            location_v = locations_country.objects.get(pk_idcountry = 1)
            location_city_v = locations_city.objects.get(pk_idcity = 1)
            datasource_v = datasources_datasource.objects.get(pk_iddatasource = 4)
            try: 
                v_brand = vehicles_brand.objects.get(name = row['make'])
            except:
                v_brand = vehicles_brand.objects.create(name = row['make'], fk_idcountry = location_v)
                print('created', row['make'])
            try:
                v_model = vehicles_model.objects.get(name = row['model'])
            except:
                v_model = vehicles_model.objects.create(name = row['model'], body = row['Tipo de carrocería'], cilinder_capacity = row['CC'],
                                                        fk_idbrand = v_brand)
            extras_v = "{color: '" + row['Color'] + "', city_cons : " + str(row['city_consum']) +", mixed_cons : " + str(row['mixed_consum']) +", images :" + row['url_imagenes'] + "}"  
            try:
                vehicle_v = vehicles_vehicle.objects.create(fk_idmodel = v_model, fk_idbrand = v_brand, fk_idlocation = location_city_v, 
                                    fk_id_datasource = datasource_v, year = int(row['year']), price = float(row['precio']),
                                    code = row['p_code'], mileage = row['kilometraje'], extras = extras_v, extra_location = row['ubicacion'],                                                        
                                    post_url = row['code'], version = '', doors = int(row['Puertas']), fuel = row['Tipo de combustible'], transmission = row['Transmisión'])
            except Exception as e:
                print(e)
                print('unable to save car', index, v_brand, v_model)
            ('total saved: ', i)
            i += 1

        for file_td in os.listdir('/home/inkremental/Documentos/Carru/extraction_ms/files/files/'):
            os.remove(f'/home/inkremental/Documentos/Carru/extraction_ms/files/files/{file_td}')
        
        return 0
