from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.decorators import api_view, renderer_classes
import requests
from main.models import *
from django.contrib.contenttypes.models import ContentType
#from datasource.api.serializers import DataSourceSerializer
from django.http import HttpResponse
from datetime import datetime
import time
from bs4 import BeautifulSoup
import datetime
import pandas as pd
import numpy as np
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import requests
import csv
import re
import json
import time

from main.views.tucarro import TuCarro
from main.views.olx import Olx

@api_view(('GET',))
def tu_carro(request):
    start = time.time()
    tucarro_val = TuCarro()
    end = time.time()
    total_time = end - start
    print('Total time' + str(total_time))
    response_  = {
        "done": "done"
    }
    return Response(response_)


@api_view(('GET',))
def olx(request):
    start = time.time()
    olx_val = Olx()
    end = time.time()
    total_time = end - start
    print('Total time' + str(total_time))
    response_  = {
        "done": "done"
    }
    return Response(response_)

